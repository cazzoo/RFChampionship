<?php
/*  //RF//Championship is a multi-racing game team manager that allows members to organize and follow championships.
    Copyright (C) 2014 - //Racing-France//

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

namespace RFC\UserBundle\Entity;

abstract class RoleEnum
{

    private static $enum = array(
        'ROLE_BANNISHED' => 'Bannished',
        'ROLE_USER' => 'Regular user',
        'ROLE_MANAGER' => 'Manager',
        'ROLE_CERTIFIED_MANAGER' => 'Certified Manager',
        'ROLE_ADMIN' => 'Administrator'
    );

    public static function toOrdinal($name)
    {
        return array_search($name, self::$enum);
    }

    public static function toString($ordinal)
    {
        return self::$enum[$ordinal];
    }
    
    public static function getEnum()
    {
        return self::$enum;
    }

    public static function getKeys()
    {
        return array_keys(self::$enum);
    }

    public static function getValues()
    {
        return array_values(self::$enum);
    }
}